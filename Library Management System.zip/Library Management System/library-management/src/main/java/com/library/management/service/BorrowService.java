package com.library.management.service;

import com.library.management.dto.BorrowRequestDTO;
import com.library.management.entity.BorrowRecord;

import java.util.List;

public interface BorrowService {

    BorrowRecord issueBook(BorrowRequestDTO dto);

    BorrowRecord returnBook(Long borrowId);

    List<BorrowRecord> getOverdueBooks();
}