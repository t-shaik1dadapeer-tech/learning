package com.library.management.service.impl;

import com.library.management.dto.BorrowRequestDTO;
import com.library.management.entity.Book;
import com.library.management.entity.BorrowRecord;
import com.library.management.entity.Member;
import com.library.management.entity.Status;
import com.library.management.exception.CustomException;
import com.library.management.repository.BookRepository;
import com.library.management.repository.BorrowRecordRepository;
import com.library.management.repository.MemberRepository;
import com.library.management.service.BorrowService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class BorrowServiceImpl implements BorrowService {

    private final BookRepository bookRepo;
    private final MemberRepository memberRepo;
    private final BorrowRecordRepository borrowRepo;

    public BorrowServiceImpl(BookRepository bookRepo,
                             MemberRepository memberRepo,
                             BorrowRecordRepository borrowRepo) {
        this.bookRepo = bookRepo;
        this.memberRepo = memberRepo;
        this.borrowRepo = borrowRepo;
    }

    // 🔥 ISSUE BOOK
    @Override
    public BorrowRecord issueBook(BorrowRequestDTO dto) {

        Book book = bookRepo.findById(dto.getBookId())
                .orElseThrow(() -> new CustomException("Book not found"));

        Member member = memberRepo.findById(dto.getMemberId())
                .orElseThrow(() -> new CustomException("Member not found"));

        if (book.getAvailableCopies() <= 0) {
            throw new CustomException("No stock available");
        }

        List<BorrowRecord> activeBorrows =
                borrowRepo.findByMemberIdAndStatus(member.getId(), Status.BORROWED);

        if (activeBorrows.size() >= 3) {
            throw new CustomException("Borrow limit exceeded");
        }

        BorrowRecord record = new BorrowRecord();
        record.setBook(book);
        record.setMember(member);
        record.setBorrowDate(LocalDate.now());

        int days = dto.getDueDays() != null ? dto.getDueDays() : 14;
        record.setDueDate(LocalDate.now().plusDays(days));

        record.setStatus(Status.BORROWED);
        record.setFineAmount(0.0);

        book.setAvailableCopies(book.getAvailableCopies() - 1);

        return borrowRepo.save(record);
    }

    // 🔥 RETURN BOOK
    @Override
    public BorrowRecord returnBook(Long borrowId) {

        BorrowRecord record = borrowRepo.findById(borrowId)
                .orElseThrow(() -> new CustomException("Borrow record not found"));

        record.setReturnDate(LocalDate.now());

        long lateDays = ChronoUnit.DAYS.between(
                record.getDueDate(),
                record.getReturnDate()
        );

        if (lateDays > 0) {
            record.setFineAmount(lateDays * 5.0);
        }

        Book book = record.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);

        record.setStatus(Status.RETURNED);

        return borrowRepo.save(record);
    }

    // 🔥 GET OVERDUE BOOKS
    @Override
    public List<BorrowRecord> getOverdueBooks() {
        return borrowRepo.findByDueDateBeforeAndStatus(
                LocalDate.now(),
                Status.BORROWED
        );
    }
}