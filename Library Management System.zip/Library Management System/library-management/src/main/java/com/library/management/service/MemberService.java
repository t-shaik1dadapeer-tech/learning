package com.library.management.service;

import com.library.management.dto.MemberDTO;
import com.library.management.entity.Member;
import com.library.management.entity.BorrowRecord;

import java.util.List;

public interface MemberService {

    Member createMember(MemberDTO dto);

    Member getMemberById(Long id);

    List<BorrowRecord> getMemberBorrows(Long memberId);
}