package com.library.management.entity;

public enum Status {
    BORROWED,
    RETURNED
}