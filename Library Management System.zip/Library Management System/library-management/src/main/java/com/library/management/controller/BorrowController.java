package com.library.management.controller;

import com.library.management.dto.BorrowRequestDTO;
import com.library.management.entity.BorrowRecord;
import com.library.management.service.BorrowService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/borrows")
public class BorrowController {

    private final BorrowService borrowService;

    public BorrowController(BorrowService borrowService) {
        this.borrowService = borrowService;
    }

    @PostMapping
    public BorrowRecord issueBook(@RequestBody BorrowRequestDTO dto) {
        return borrowService.issueBook(dto);
    }

    @PatchMapping("/{id}/return")
    public BorrowRecord returnBook(@PathVariable Long id) {
        return borrowService.returnBook(id);
    }

    @GetMapping("/overdue")
    public List<BorrowRecord> getOverdue() {
        return borrowService.getOverdueBooks();
    }
}