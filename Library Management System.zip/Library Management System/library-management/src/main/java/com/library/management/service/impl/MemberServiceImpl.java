package com.library.management.service.impl;

import com.library.management.dto.MemberDTO;
import com.library.management.entity.BorrowRecord;
import com.library.management.entity.Member;
import com.library.management.entity.Status;
import com.library.management.exception.CustomException;
import com.library.management.repository.BorrowRecordRepository;
import com.library.management.repository.MemberRepository;
import com.library.management.service.MemberService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;
    private final BorrowRecordRepository borrowRepo;

    public MemberServiceImpl(MemberRepository memberRepository,
                             BorrowRecordRepository borrowRepo) {
        this.memberRepository = memberRepository;
        this.borrowRepo = borrowRepo;
    }

    @Override
    public Member createMember(MemberDTO dto) {

        memberRepository.findByEmail(dto.getEmail()).ifPresent(m -> {
            throw new CustomException("Email already exists");
        });

        Member member = new Member();
        member.setName(dto.getName());
        member.setEmail(dto.getEmail());
        member.setPhone(dto.getPhone());
        member.setMembershipDate(LocalDate.now());

        return memberRepository.save(member);
    }

    @Override
    public Member getMemberById(Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new CustomException("Member not found"));
    }

    @Override
    public List<BorrowRecord> getMemberBorrows(Long memberId) {
        return borrowRepo.findByMemberIdAndStatus(memberId, Status.BORROWED);
    }
}