package com.library.management.dto;

import java.time.LocalDate;

public class BorrowResponseDTO {
    private Long id;
    private String bookTitle;
    private String memberName;

    private LocalDate borrowDate;
    private LocalDate dueDate;
    private  LocalDate returnDate;

    private Double fineAmount;
    private String status;

}
