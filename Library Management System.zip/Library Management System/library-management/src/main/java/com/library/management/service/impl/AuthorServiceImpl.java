package com.library.management.service.impl;

import com.library.management.dto.AuthorDTO;
import com.library.management.entity.Author;
import com.library.management.exception.CustomException;
import com.library.management.repository.AuthorRepository;
import com.library.management.service.AuthorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorServiceImpl implements AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorServiceImpl(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @Override
    public Author createAuthor(AuthorDTO dto) {
        Author author = new Author();
        author.setName(dto.getName());
        author.setNationality(dto.getNationality());
        author.setBio(dto.getBio());
        return authorRepository.save(author);
    }

    @Override
    public List<Author> getAllAuthors() {
        return authorRepository.findAll();
    }

    @Override
    public Author getAuthorById(Long id) {
        return authorRepository.findById(id)
                .orElseThrow(() -> new CustomException("Author not found"));
    }

    @Override
    public Author updateAuthor(Long id, AuthorDTO dto) {
        Author author = getAuthorById(id);
        author.setName(dto.getName());
        author.setNationality(dto.getNationality());
        author.setBio(dto.getBio());
        return authorRepository.save(author);
    }
}