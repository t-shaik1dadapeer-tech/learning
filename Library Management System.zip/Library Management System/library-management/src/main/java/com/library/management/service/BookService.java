package com.library.management.service;

import com.library.management.dto.BookDTO;
import com.library.management.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface BookService {

    Book createBook(BookDTO dto);

    Page<Book> getAllBooks(Pageable pageable);

    List<Book> searchBooks(String query);

    Book getBookById(Long id);

    Book updateBook(Long id, BookDTO dto);
}