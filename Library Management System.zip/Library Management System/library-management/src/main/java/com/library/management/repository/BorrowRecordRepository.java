package com.library.management.repository;

import com.library.management.entity.BorrowRecord;
import com.library.management.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface BorrowRecordRepository extends JpaRepository<BorrowRecord, Long> {

    List<BorrowRecord> findByMemberIdAndStatus(Long memberId, Status status);

    List<BorrowRecord> findByDueDateBeforeAndStatus(LocalDate date, Status status);
}