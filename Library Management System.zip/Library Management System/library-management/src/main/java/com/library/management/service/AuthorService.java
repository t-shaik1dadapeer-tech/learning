package com.library.management.service;

import com.library.management.dto.AuthorDTO;
import com.library.management.entity.Author;

import java.util.List;

public interface AuthorService {

    Author createAuthor(AuthorDTO dto);

    List<Author> getAllAuthors();

    Author getAuthorById(Long id);

    Author updateAuthor(Long id, AuthorDTO dto);
}