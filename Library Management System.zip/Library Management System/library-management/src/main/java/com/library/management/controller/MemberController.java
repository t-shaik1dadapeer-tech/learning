package com.library.management.controller;

import com.library.management.dto.MemberDTO;
import com.library.management.entity.Member;
import com.library.management.entity.BorrowRecord;
import com.library.management.service.MemberService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/members")
public class MemberController {

    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @PostMapping
    public Member createMember(@RequestBody MemberDTO dto) {
        return memberService.createMember(dto);
    }

    @GetMapping("/{id}")
    public Member getMember(@PathVariable Long id) {
        return memberService.getMemberById(id);
    }

    @GetMapping("/{id}/borrows")
    public List<BorrowRecord> getBorrows(@PathVariable Long id) {
        return memberService.getMemberBorrows(id);
    }
}